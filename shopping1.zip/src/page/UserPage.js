import React from 'react'

const UserPage = () => {
  return (
    <div>
      <h1>UserPage</h1>
    </div>
  )
}

export default UserPage
